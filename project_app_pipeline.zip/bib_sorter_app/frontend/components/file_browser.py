from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                            QLineEdit, QPushButton, QFileDialog, QGroupBox)
from PyQt5.QtCore import pyqtSignal, Qt

class FileInputWidget(QGroupBox):
    process_requested = pyqtSignal(str, str)  # (input_path, output_path)
    
    def __init__(self):
        super().__init__("Input/Output Selection")
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Input directory selection
        input_layout = QHBoxLayout()
        self.input_label = QLabel("Input Directory:")
        self.input_path = QLineEdit()
        self.input_path.setPlaceholderText("Select directory containing images...")
        self.input_browse = QPushButton("Browse...")
        
        input_layout.addWidget(self.input_label)
        input_layout.addWidget(self.input_path)
        input_layout.addWidget(self.input_browse)
        
        # Output directory selection
        output_layout = QHBoxLayout()
        self.output_label = QLabel("Output Directory:")
        self.output_path = QLineEdit()
        self.output_path.setPlaceholderText("Select directory for sorted output...")
        self.output_browse = QPushButton("Browse...")
        
        output_layout.addWidget(self.output_label)
        output_layout.addWidget(self.output_path)
        output_layout.addWidget(self.output_browse)
        
        # Process button
        self.process_btn = QPushButton("Start Processing")
        self.process_btn.setEnabled(False)
        
        layout.addLayout(input_layout)
        layout.addLayout(output_layout)
        layout.addWidget(self.process_btn, 0, Qt.AlignRight)
        
        # Connect signals
        self.input_browse.clicked.connect(self._browse_input)
        self.output_browse.clicked.connect(self._browse_output)
        self.process_btn.clicked.connect(self._emit_process_request)
        
        # Enable process button when both paths are set
        self.input_path.textChanged.connect(self._validate_paths)
        self.output_path.textChanged.connect(self._validate_paths)
    
    def _browse_input(self):
        path = QFileDialog.getExistingDirectory(self, "Select Input Directory")
        if path:
            self.input_path.setText(path)
    
    def _browse_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if path:
            self.output_path.setText(path)
    
    def _validate_paths(self):
        """Enable process button only when both paths are valid"""
        input_valid = bool(self.input_path.text())
        output_valid = bool(self.output_path.text())
        self.process_btn.setEnabled(input_valid and output_valid)
    
    def _emit_process_request(self):
        """Emit signal with current paths"""
        self.process_requested.emit(
            self.input_path.text(),
            self.output_path.text()
        )