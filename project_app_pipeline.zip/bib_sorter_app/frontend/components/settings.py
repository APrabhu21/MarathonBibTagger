# frontend/components/settings.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QFormLayout,
                            QDoubleSpinBox, QSpinBox, QCheckBox,
                            QPushButton, QGroupBox)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QIcon

class SettingsPanel(QWidget):
    settings_saved = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        self._setup_ui()
        self._load_defaults()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Detection settings
        det_group = QGroupBox("Detection Settings")
        det_layout = QFormLayout(det_group)
        
        self.conf_thresh = QDoubleSpinBox()
        self.conf_thresh.setRange(0.1, 1.0)
        self.conf_thresh.setSingleStep(0.05)
        
        self.iou_thresh = QDoubleSpinBox()
        self.iou_thresh.setRange(0.1, 1.0)
        self.iou_thresh.setSingleStep(0.05)
        
        self.max_detections = QSpinBox()
        self.max_detections.setRange(1, 50)
        
        det_layout.addRow("Confidence Threshold:", self.conf_thresh)
        det_layout.addRow("IOU Threshold:", self.iou_thresh)
        det_layout.addRow("Max Detections:", self.max_detections)
        
        # Output settings
        out_group = QGroupBox("Output Settings")
        out_layout = QFormLayout(out_group)
        
        self.create_subdirs = QCheckBox()
        self.overwrite = QCheckBox()
        self.save_debug = QCheckBox()
        
        out_layout.addRow("Create Subdirectories:", self.create_subdirs)
        out_layout.addRow("Overwrite Existing:", self.overwrite)
        out_layout.addRow("Save Debug Images:", self.save_debug)
        
        # Save button
        self.save_btn = QPushButton(QIcon(":/icons/save.svg"), "Save Settings")
        
        layout.addWidget(det_group)
        layout.addWidget(out_group)
        layout.addWidget(self.save_btn)
        
        # Connections
        self.save_btn.clicked.connect(self._save_settings)

    def _save_settings(self):
        """Emit current settings"""
        settings = {
            'detection': {
                'confidence': self.conf_thresh.value(),
                'iou_threshold': self.iou_thresh.value(),
                'max_detections': self.max_detections.value()
            },
            'output': {
                'create_subdirs': self.create_subdirs.isChecked(),
                'overwrite': self.overwrite.isChecked(),
                'save_debug': self.save_debug.isChecked()
            }
        }
        self.settings_saved.emit(settings)

    def _load_defaults(self):
        """Set default values"""
        self.conf_thresh.setValue(0.5)
        self.iou_thresh.setValue(0.45)
        self.max_detections.setValue(10)
        self.create_subdirs.setChecked(True)
        self.overwrite.setChecked(False)
        self.save_debug.setChecked(False)