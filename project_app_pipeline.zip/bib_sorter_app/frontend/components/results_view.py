# frontend/components/results_view.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                            QListWidget, QGraphicsView, QGraphicsScene,
                            QSplitter, QListWidgetItem, QSizePolicy)
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt, QSize

class ResultsViewer(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()
    
    def _setup_ui(self):
        self.splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Results list
        self.results_list = QListWidget()
        self.results_list.setMinimumWidth(250)
        self.results_list.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Expanding)
        
        # Right panel - Image viewer
        self.image_view = QGraphicsView()
        self.image_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.image_scene = QGraphicsScene()
        self.image_view.setScene(self.image_scene)
        
        # Setup splitter
        self.splitter.addWidget(self.results_list)
        self.splitter.addWidget(self.image_view)
        self.splitter.setSizes([250, 600])
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Detection Results:"))
        layout.addWidget(self.splitter)
        
        # Connections
        self.results_list.itemClicked.connect(self._show_selected_image)

    def add_result(self, bib_number: str, image_path: str):
        """Add a new result to the viewer"""
        item = QListWidgetItem(f"Bib: {bib_number}")
        item.setData(Qt.UserRole, image_path)
        self.results_list.addItem(item)

    def _show_selected_image(self, item: QListWidgetItem):
        """Display the selected image"""
        pixmap = QPixmap(item.data(Qt.UserRole))
        if not pixmap.isNull():
            self.image_scene.clear()
            self.image_scene.addPixmap(pixmap)
            self.image_view.fitInView(self.image_scene.itemsBoundingRect(), Qt.KeepAspectRatio)

    def clear_results(self):
        """Clear all results"""
        self.results_list.clear()
        self.image_scene.clear()