from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                            QProgressBar, QPushButton)
from PyQt5.QtCore import Qt,pyqtSignal

class ProcessingProgress(QWidget):
    cancel_requested = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self._setup_ui()
        self._reset_state()
    
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setRange(0, 100)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setAlignment(Qt.AlignCenter)
        
        # Cancel button
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        
        # Layout for button (centered)
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self.cancel_btn)
        btn_layout.addStretch()
        
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.status_label)
        layout.addLayout(btn_layout)
        
        # Connect signals
        self.cancel_btn.clicked.connect(self.cancel_requested.emit)
    
    def _reset_state(self):
        """Reset to initial state"""
        self.progress_bar.setValue(0)
        self.status_label.setText("Ready")
        self.cancel_btn.setEnabled(False)
    
    def start_progress(self):
        """Begin processing state"""
        self.progress_bar.setValue(0)
        self.status_label.setText("Processing...")
        self.cancel_btn.setEnabled(True)
    
    def update_progress(self, value, message=None):
        """Update progress value and optional message"""
        self.progress_bar.setValue(value)
        if message:
            self.status_label.setText(message)
    
    def complete_progress(self, success=True, message=None):
        """Complete processing state"""
        self.progress_bar.setValue(100)
        self.status_label.setText(message or ("Completed successfully!" if success else "Processing failed"))
        self.cancel_btn.setEnabled(False)