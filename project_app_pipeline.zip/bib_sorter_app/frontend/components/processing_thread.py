# frontend/components/processing_thread.py
import time
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from PyQt5.QtCore import QThread, pyqtSignal, QObject, QRunnable, pyqtSlot, QThreadPool

@dataclass
class ProcessingConfig:
    human_confidence: float = 0.2
    number_confidence: float = 0.2
    max_detections: int = 10
    skip_existing: bool = True

class ProcessingSignals(QObject):
    progress_updated = pyqtSignal(int, str, float)  # (percent, message, eta)
    image_processed = pyqtSignal(str, List[str], dict)  # (path, bibs, metadata)
    batch_complete = pyqtSignal(int, int)  # (processed, total)
    finished = pyqtSignal(bool, str, dict)  # (success, message, stats)
    error_occurred = pyqtSignal(str, str)  # (path, error)

class ProcessingStats:
    def __init__(self):
        self.start_time = time.time()
        self.processed = 0
        self.skipped = 0
        self.errors = 0
        self.bibs_detected = 0
    
    def as_dict(self) -> Dict[str, Any]:
        duration = time.time() - self.start_time
        return {
            "total_time": f"{duration:.1f}s",
            "images_processed": self.processed,
            "images_skipped": self.skipped,
            "errors_occurred": self.errors,
            "total_bibs": self.bibs_detected,
            "rate": f"{self.processed/max(1,duration):.1f} img/s"
        }

class ProcessingTask(QRunnable):
    def __init__(self, image_path: str, sorter, config: ProcessingConfig):
        super().__init__()
        self.image_path = image_path
        self.sorter = sorter
        self.config = config
        self.signals = ProcessingSignals()
        self.metadata = {
            "detection_time": None,
            "bib_count": 0
        }

    @pyqtSlot()
    def run(self):
        try:
            start_time = time.time()
            
            bibs = self.sorter.detect_bibs_on_image(
                self.image_path,
                human_confidence=self.config.human_confidence,
                number_confidence=self.config.number_confidence,
                max_detections=self.config.max_detections
            )
            
            self.metadata.update({
                "detection_time": time.time() - start_time,
                "bib_count": len(bibs)
            })
            
            self.signals.image_processed.emit(
                self.image_path,
                bibs,
                self.metadata
            )
            
        except Exception as e:
            self.signals.error_occurred.emit(self.image_path, str(e))

class ProcessingController(QObject):
    def __init__(self, sorter):
        super().__init__()
        self.sorter = sorter
        self.config = ProcessingConfig()
        self.thread_pool = QThreadPool()
        self.thread_pool.setMaxThreadCount(4)
        self._is_running = False
        self.signals = ProcessingSignals()
        self.stats = ProcessingStats()

    def configure(self, **kwargs):
        """Update processing configuration"""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)

    def process_folder(self, input_path: str, output_path: str):
        """Start processing all images in folder"""
        if self._is_running:
            self.signals.error_occurred.emit("", "Processing already running")
            return

        self._is_running = True
        self.stats = ProcessingStats()
        image_paths = [str(p) for p in Path(input_path).glob("*") if p.suffix.lower() in ['.jpg', '.jpeg', '.png']]
        total_images = len(image_paths)

        for i, img_path in enumerate(image_paths):
            if not self._is_running:
                break

            task = ProcessingTask(img_path, self.sorter, self.config)
            task.signals.image_processed.connect(self._handle_image_processed)
            task.signals.error_occurred.connect(self._handle_error)
            self.thread_pool.start(task)

            # Calculate ETA (simple linear projection)
            if i > 0:
                elapsed = time.time() - self.stats.start_time
                eta = (elapsed / (i+1)) * (total_images - (i+1))
                self.signals.progress_updated.emit(
                    int((i+1)/total_images*100),
                    f"Processing {i+1}/{total_images}",
                    eta
                )

        self.thread_pool.waitForDone()
        self._is_running = False
        self.signals.finished.emit(
            True,
            "Processing completed",
            self.stats.as_dict()
        )

    def _handle_image_processed(self, img_path: str, bibs: List[str], metadata: dict):
        """Handle successful image processing"""
        self.stats.processed += 1
        self.stats.bibs_detected += len(bibs)
        # Add your file organization logic here

    def _handle_error(self, img_path: str, error: str):
        """Handle processing errors"""
        self.stats.errors += 1
        self.signals.error_occurred.emit(img_path, error)

    def cancel(self):
        """Cancel ongoing processing"""
        self._is_running = False
        self.thread_pool.clear()
        self.signals.finished.emit(
            False,
            "Processing cancelled",
            self.stats.as_dict()
        )