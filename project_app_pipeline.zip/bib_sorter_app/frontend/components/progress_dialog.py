# frontend/components/progress_dialog.py
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QProgressBar, QPushButton
from PyQt5.QtCore import Qt, QTimer

class ProcessingDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Processing Images")
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        self.setModal(True)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Progress information
        self.progress_label = QLabel("Preparing to process images...")
        self.progress_label.setAlignment(Qt.AlignCenter)
        
        # Detailed status
        self.status_label = QLabel()
        self.status_label.setAlignment(Qt.AlignCenter)
        
        # ETA display
        self.eta_label = QLabel()
        self.eta_label.setAlignment(Qt.AlignCenter)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        
        # Cancel button
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        
        layout.addWidget(self.progress_label)
        layout.addWidget(self.status_label)
        layout.addWidget(self.eta_label)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.cancel_btn)

    def update_progress(self, percent: int, message: str, eta: float):
        """Update all progress indicators"""
        self.progress_bar.setValue(percent)
        self.status_label.setText(message)
        
        if eta > 0:
            eta_str = time.strftime("%H:%M:%S", time.gmtime(eta))
            self.eta_label.setText(f"Estimated time remaining: {eta_str}")
        
        # Force UI update
        QApplication.processEvents()

    def show_completion(self, success: bool, message: str):
        """Show final state before closing"""
        self.progress_label.setText("Processing complete" if success else "Processing stopped")
        self.status_label.setText(message)
        self.cancel_btn.setText("Close")
        
        # Auto-close after 3 seconds
        QTimer.singleShot(3000, self.accept)