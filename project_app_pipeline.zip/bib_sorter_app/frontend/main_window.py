# frontend/main_window.py
from __future__ import annotations
import logging
from pathlib import Path
from typing import List, Dict, Any
from PyQt5.QtWidgets import (QMainWindow, QFileDialog, QMessageBox, 
                            QApplication, QStyleFactory, QVBoxLayout,
                            QWidget, QTabWidget, QStatusBar)
from PyQt5.QtCore import pyqtSignal, Qt, QFile, QTextStream
from PyQt5.QtGui import QIcon, QGuiApplication

from .components.file_browser import FileInputWidget
from .components.progress import ProcessingProgress
from .components.results_view import ResultsViewer
from .components.settings import SettingsPanel
from .components.processing_thread import ProcessingController
from .components.progress_dialog import ProcessingDialog

logger = logging.getLogger(__name__)

class BibSorterApp(QMainWindow):
    def __init__(self, sorter):
        super().__init__()
        self.sorter = sorter
        self.controller = None
        self.processing_dialog = None
        
        # Window setup
        self.setWindowTitle("BIB Sorter Pro")
        self.setMinimumSize(1024, 768)
        self.setWindowIcon(QIcon(":/icons/app_icon.svg"))
        
        # Initialize UI
        self._setup_ui()
        self._load_application_style()
        self._connect_signals()

    def _setup_ui(self):
        """Initialize all UI components"""
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create tab interface
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        # Process Tab
        process_tab = QWidget()
        process_layout = QVBoxLayout(process_tab)
        
        self.file_input = FileInputWidget()
        self.progress = ProcessingProgress()
        
        process_layout.addWidget(self.file_input)
        process_layout.addWidget(self.progress)
        self.tabs.addTab(process_tab, QIcon(":/icons/process.svg"), "Process")
        
        # Results Tab
        self.results_viewer = ResultsViewer()
        self.tabs.addTab(self.results_viewer, QIcon(":/icons/results.svg"), "Results")
        
        # Settings Tab
        self.settings_panel = SettingsPanel()
        self.tabs.addTab(self.settings_panel, QIcon(":/icons/settings.svg"), "Settings")
        
        # Status Bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Initialize processing dialog
        self.processing_dialog = ProcessingDialog(self)

    def _load_application_style(self):
        """Load and apply application styles with fallback handling"""
        try:
            # Try loading from compiled resources first
            file = QFile(":/styles/main_style.qss")
            if file.open(QFile.ReadOnly | QFile.Text):
                stream = QTextStream(file)
                self.setStyleSheet(stream.readAll())
                logger.debug("Stylesheet loaded from resources")
        except Exception as e:
            logger.warning(f"Couldn't load styles from resources: {e}")
            try:
                # Fallback to filesystem
                style_path = Path(__file__).parent / "styles" / "main_style.qss"
                with open(style_path, "r", encoding="utf-8") as f:
                    self.setStyleSheet(f.read())
                logger.debug("Stylesheet loaded from filesystem")
            except Exception as e:
                logger.error(f"Couldn't load stylesheet: {e}")
                QApplication.setStyle(QStyleFactory.create("Fusion"))
        
        # Apply platform-specific adjustments
        self._apply_platform_fixes()

    def _apply_platform_fixes(self):
        """Platform-specific UI adjustments"""
        if Qt.platform.system().lower() == "windows":
            self.setStyleSheet(self.styleSheet() + """
                QTabBar::tab { padding: 6px 12px; }
                QStatusBar { padding: 4px; }
            """)

    def _connect_signals(self):
        """Connect all UI signals"""
        self.file_input.process_requested.connect(self._start_processing)
        self.progress.cancel_requested.connect(self._cancel_processing)
        self.settings_panel.settings_saved.connect(self._on_settings_saved)

    def _start_processing(self, input_path: str, output_path: str):
        """Start the processing pipeline"""
        if not Path(input_path).exists():
            QMessageBox.warning(self, "Invalid Input", 
                               "Input directory does not exist")
            return

        try:
            self._set_ui_processing_state(True)
            self.processing_dialog.show()
            
            # Initialize processing controller
            self.controller = ProcessingController(self.sorter)
            
            # Connect controller signals
            self.controller.signals.progress_updated.connect(
                lambda p, m, e: self._update_progress(p, m, e)
            self.controller.signals.image_processed.connect(
                self._on_image_processed)
            self.controller.signals.finished.connect(
                lambda s, m, _: self._on_processing_finished(s, m))
            self.controller.signals.error_occurred.connect(
                self._on_processing_error)
            
            # Start processing
            self.controller.process_folder(input_path, output_path)
            
        except Exception as e:
            logger.error(f"Failed to start processing: {str(e)}")
            self._set_ui_processing_state(False)
            self.processing_dialog.hide()
            QMessageBox.critical(self, "Processing Error", str(e))

    def _update_progress(self, percent: int, message: str, eta: float):
        """Update progress indicators"""
        self.progress.update_progress(percent, message, eta)
        self.processing_dialog.update_progress(percent, message, eta)
        self.status_bar.showMessage(message)
        QApplication.processEvents()  # Ensure UI updates

    def _on_image_processed(self, image_path: str, bib_numbers: List[str], metadata: Dict[str, Any]):
        """Handle successfully processed image"""
        filename = Path(image_path).name
        if bib_numbers:
            self.results_viewer.add_result(", ".join(bib_numbers), image_path)
            logger.info(f"Processed {filename} → Bibs: {', '.join(bib_numbers)} "
                       f"(Time: {metadata['processing_time']:.2f}s)")
        else:
            logger.info(f"Processed {filename} → No bibs detected")

    def _on_processing_finished(self, success: bool, message: str, stats: Dict[str, Any]):
        """Handle processing completion"""
        self._set_ui_processing_state(False)
        self.progress.complete_progress(success, message)
        self.processing_dialog.show_completion(success, message)
        
        # Show summary stats if successful
        if success:
            summary = (f"Processing complete!\n"
                      f"Images processed: {stats['images_processed']}\n"
                      f"Bibs detected: {stats['total_bibs']}\n"
                      f"Processing rate: {stats['rate']}")
            QMessageBox.information(self, "Processing Complete", summary)
        else:
            QMessageBox.warning(self, "Processing Stopped", message)

    def _on_processing_error(self, image_path: str, error: str):
        """Handle individual image processing errors"""
        filename = Path(image_path).name
        logger.error(f"Error processing {filename}: {error}")
        self.status_bar.showMessage(f"Error processing {filename}", 5000)

    def _cancel_processing(self):
        """Cancel ongoing processing"""
        if self.controller:
            self.controller.cancel()
        self.progress.complete_progress(False, "Processing cancelled")
        self.processing_dialog.show_completion(False, "Processing cancelled by user")
        self._set_ui_processing_state(False)

    def _set_ui_processing_state(self, processing: bool):
        """Enable/disable UI elements during processing"""
        self.file_input.setEnabled(not processing)
        self.settings_panel.setEnabled(not processing)
        self.progress.setCancelEnabled(processing)
        self.tabs.setTabEnabled(1, not processing)  # Disable Results tab during processing
        self.tabs.setTabEnabled(2, not processing)  # Disable Settings tab during processing

    def _on_settings_saved(self, settings: dict):
        """Apply new settings to the sorter"""
        try:
            self.sorter.configure(**settings)
            self.status_bar.showMessage("Settings applied successfully", 3000)
            logger.info(f"Updated settings: {settings}")
        except Exception as e:
            logger.error(f"Failed to apply settings: {str(e)}")
            QMessageBox.warning(self, "Settings Error", str(e))