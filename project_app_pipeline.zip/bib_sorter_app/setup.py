import os
from pathlib import Path

def setup_models_if_needed():
    model_dir = Path("models")
    model_dir.mkdir(exist_ok=True)

    # Expected files
    craft_model = model_dir / "text_detector_craft.pth"
    human_yolo = model_dir / "human_detector_yolov8.pt"
    number_yolo = model_dir / "number_detector_yolov8n.pt"

    if not craft_model.exists():
        raise FileNotFoundError("CRAFT model missing! Place 'text_detector_craft.pth' in models/.")

    if not human_yolo.exists():
        print(" Human detector model not found: 'human_detector_yolov8.pt' in models/")
    if not number_yolo.exists():
        print(" Number detector model not found: 'number_detector_yolov8n.pt' in models/")
