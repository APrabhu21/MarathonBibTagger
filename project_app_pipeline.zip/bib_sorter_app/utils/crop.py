import cv2

def crop_torso_from_box(image, box):
    x1, y1, x2, y2 = map(int, box)
    
    # Compute dimensions
    w = x2 - x1
    h = y2 - y1

    # Heuristic: crop vertical center third for torso region
    torso_top = y1 + h // 3
    torso_bottom = y1 + (2 * h) // 3

    # Boundary checks
    torso_top = max(0, torso_top)
    torso_bottom = min(image.shape[0], torso_bottom)

    cropped = image[torso_top:torso_bottom, x1:x2]
    return cropped
