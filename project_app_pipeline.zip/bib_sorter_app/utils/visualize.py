import cv2
import matplotlib.pyplot as plt


def plot_bib_boxes(image, boxes, color=(0, 255, 0), thickness=2, title="Detected Bib Numbers"):
    """
    Draws bounding boxes on a copy of the image and displays it using matplotlib.

    :param image: Input image (BGR format)
    :param boxes: List of bounding boxes in format (x1, y1, x2, y2)
    :param color: Bounding box color (BGR tuple)
    :param thickness: Line thickness
    :param title: Title to display above the image
    """
    image_copy = image.copy()
    for box in boxes:
        x1, y1, x2, y2 = map(int, box)
        cv2.rectangle(image_copy, (x1, y1), (x2, y2), color, thickness)

    # Convert BGR to RGB for matplotlib
    image_rgb = cv2.cvtColor(image_copy, cv2.COLOR_BGR2RGB)

    plt.figure(figsize=(10, 8))
    plt.imshow(image_rgb)
    plt.title(title)
    plt.axis("off")
    plt.tight_layout()
    plt.show()
