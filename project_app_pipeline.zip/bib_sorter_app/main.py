import os
import shutil
import argparse
import logging
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import torch
from ultralytics import YOLO

from utils.imgproc import loadImage
from utils.craft_utils import getDetBoxes, adjustResultCoordinates
from craft_model import load_craft_model, run_craft_inference
from utils.visualize import plot_bib_boxes
from utils.crop import crop_torso_from_box
from setup import setup_models_if_needed

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class BibSorter:
    def __init__(self):
        """Initialize the bib sorter with loaded models"""
        self.human_model = None
        self.number_model = None
        self.craft_model = None
        self._models_loaded = False

    def load_models(self, model_dir: str = "models") -> bool:
        """Load all required models"""
        try:
            logger.info("Loading models...")
            setup_models_if_needed()
            
            self.human_model = YOLO(str(Path(model_dir) / "human_detector_yolov8.pt"))
            self.number_model = YOLO(str(Path(model_dir) / "number_detector_yolov8n.pt"))
            self.craft_model = load_craft_model(str(Path(model_dir) / "text_detector_craft.pth"))
            
            self._models_loaded = True
            logger.info("Models loaded successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to load models: {str(e)}")
            self._models_loaded = False
            return False

    def detect_bibs_on_image(
        self, 
        image_path: str, 
        show: bool = False,
        human_confidence: float = 0.2,
        number_confidence: float = 0.2
    ) -> List[str]:
        """
        Detect bib numbers on a single image.
        
        Args:
            image_path: Path to the input image
            show: Whether to display detection results
            human_confidence: Confidence threshold for human detection
            number_confidence: Confidence threshold for number detection
            
        Returns:
            List of detected bib numbers (empty if none found)
        """
        if not self._models_loaded:
            logger.error("Models not loaded. Call load_models() first.")
            return []

        try:
            orig_img = cv2.imread(image_path)
            if orig_img is None:
                logger.error(f"Could not load image: {image_path}")
                return []

            # Step 1: Human detection
            human_results = self.human_model.predict(
                orig_img, 
                conf=human_confidence, 
                classes=[0], 
                verbose=False
            )
            people_boxes = [r.boxes.xyxy[0].cpu().numpy() for r in human_results if r.boxes.shape[0] > 0]
            
            if not people_boxes:
                logger.debug(f"No people detected in {image_path}")
                return []

            all_bib_numbers = []

            for box in people_boxes:
                cropped = crop_torso_from_box(orig_img, box)

                # Step 2: CRAFT text box detection
                bboxes, _ = run_craft_inference(self.craft_model, cropped)

                for bbox in bboxes:
                    x1, y1 = bbox[0]
                    x2, y2 = bbox[2]

                    # Safeguard: check box coordinates
                    if x2 <= x1 or y2 <= y1:
                        continue

                    bib_crop = cropped[int(y1):int(y2), int(x1):int(x2)]

                    # Safeguard: check for empty crops
                    if bib_crop is None or bib_crop.size == 0 or bib_crop.shape[0] == 0 or bib_crop.shape[1] == 0:
                        continue

                    # Step 3: Number detection (YOLO)
                    num_results = self.number_model.predict(
                        bib_crop, 
                        conf=number_confidence, 
                        verbose=False
                    )
                    
                    for r in num_results:
                        digits = []
                        for box in r.boxes:
                            cls = int(box.cls[0])
                            number = r.names[cls]
                            x1 = int(box.xyxy[0][0])  # get left coordinate for sorting
                            digits.append((x1, number))

                        # Sort digits by their left x-coordinate to form a number
                        digits_sorted = [d[1] for d in sorted(digits, key=lambda x: x[0])]
                        bib_number = ''.join(digits_sorted)

                        if bib_number:
                            all_bib_numbers.append(bib_number)

                            if show:
                                # Visualize detection
                                plot_img = plot_bib_boxes(orig_img, box, bbox, bib_number)
                                cv2.imshow(f"Bib Detection: {bib_number}", plot_img)
                                cv2.waitKey(500 if len(all_bib_numbers) > 1 else 0)
                                cv2.destroyAllWindows()

            return list(set(all_bib_numbers))  # return unique numbers

        except Exception as e:
            logger.error(f"Error processing image {image_path}: {str(e)}")
            return []

    def process_folder(
        self,
        input_folder: str,
        output_folder: str,
        show: bool = False,
        copy_mode: bool = True,
        unknown_folder: str = "unknown"
    ) -> Tuple[int, int]:
        """
        Process all images in a folder and sort them by bib numbers.
        
        Args:
            input_folder: Path to folder with input images
            output_folder: Path to save sorted bib folders
            show: Whether to show detection results
            copy_mode: If True copies files, otherwise moves them
            unknown_folder: Name for folder with images without detected bibs
            
        Returns:
            Tuple of (processed_count, success_count)
        """
        if not self._models_loaded:
            logger.error("Models not loaded. Call load_models() first.")
            return 0, 0

        input_path = Path(input_folder)
        output_path = Path(output_folder)
        output_path.mkdir(parents=True, exist_ok=True)
        
        processed = 0
        success = 0
        unknown_path = output_path / unknown_folder
        unknown_path.mkdir(exist_ok=True)

        for img_path in input_path.glob("*.*"):
            if img_path.suffix.lower() not in ['.jpg', '.jpeg', '.png']:
                continue

            try:
                bibs = self.detect_bibs_on_image(str(img_path), show=show)
                processed += 1

                if not bibs:
                    dest = unknown_path / img_path.name
                else:
                    # Create subfolders for each bib number
                    for bib in bibs:
                        bib_dir = output_path / str(bib)
                        bib_dir.mkdir(exist_ok=True)
                        dest = bib_dir / img_path.name
                        
                        if copy_mode:
                            shutil.copy(str(img_path), str(dest))
                        else:
                            shutil.move(str(img_path), str(dest))
                    success += 1

                logger.info(f"{img_path.name} → {bibs if bibs else 'unknown'}")
                
                if not bibs:
                    if copy_mode:
                        shutil.copy(str(img_path), str(unknown_path / img_path.name))
                    else:
                        shutil.move(str(img_path), str(unknown_path / img_path.name))

            except Exception as e:
                logger.error(f"Failed to process {img_path.name}: {str(e)}")

        logger.info(f"Processing complete. Processed: {processed}, Success: {success}")
        return processed, success

def main_cli():
    """Command line interface for the bib sorter"""
    parser = argparse.ArgumentParser(
        description="BIB_SORTER_APP - Detect and sort marathon bib numbers from images"
    )
    parser.add_argument(
        "--input", 
        required=True, 
        help="Path to folder with input images"
    )
    parser.add_argument(
        "--output", 
        required=True, 
        help="Path to save sorted bib folders"
    )
    parser.add_argument(
        "--show", 
        action="store_true", 
        help="Show sample bib detection results"
    )
    parser.add_argument(
        "--move", 
        action="store_true", 
        help="Move files instead of copying"
    )
    parser.add_argument(
        "--human-conf", 
        type=float, 
        default=0.2,
        help="Confidence threshold for human detection (0-1)"
    )
    parser.add_argument(
        "--number-conf", 
        type=float, 
        default=0.2,
        help="Confidence threshold for number detection (0-1)"
    )
    parser.add_argument(
        "--verbose", 
        action="store_true", 
        help="Enable verbose logging"
    )

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    sorter = BibSorter()
    if not sorter.load_models():
        return

    processed, success = sorter.process_folder(
        args.input,
        args.output,
        show=args.show,
        copy_mode=not args.move,
    )

    print(f"\nProcessing complete!\nImages processed: {processed}\nSuccessfully sorted: {success}")

if __name__ == "__main__":
    # Check if we're running in CLI mode or GUI mode
    try:
        from PyQt5.QtWidgets import QApplication
        # If PyQt5 imports successfully, we'll assume GUI mode
        from frontend.main_window import BibSorterApp
        
        def run_gui():
            app = QApplication([])
            window = BibSorterApp()
            window.show()
            app.exec_()
        
        run_gui()
    except ImportError:
        # Fall back to CLI mode
        main_cli()
    except Exception as e:
        logger.error(f"Failed to start application: {str(e)}")
        print("Falling back to command line interface...")
        main_cli()