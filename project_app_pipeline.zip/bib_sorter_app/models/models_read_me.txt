place model weights from ubbox here, human,text and number detectors
