# craft_model.py
import torch
import torch.nn as nn
import torch.nn.init as init
import torchvision
import torch.nn.functional as F

from torchvision import models
from packaging import version
from collections import OrderedDict
import numpy as np
import os
from utils.imgproc import loadImage, resize_aspect_ratio, normalizeMeanVariance
from utils.craft_utils import getDetBoxes, adjustResultCoordinates
#from craft.model import CRAFT
import cv2



def init_weights(modules):
    for m in modules:
        if isinstance(m, nn.Conv2d):
            init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.zero_()
        elif isinstance(m, nn.BatchNorm2d):
            m.weight.data.fill_(1)
            m.bias.data.zero_()
        elif isinstance(m, nn.Linear):
            m.weight.data.normal_(0, 0.01)
            m.bias.data.zero_()


class vgg16_bn(torch.nn.Module):
    def __init__(self, pretrained=True, freeze=True):
        super(vgg16_bn, self).__init__()
        if version.parse(torchvision.__version__) >= version.parse('0.13'):
            vgg_pretrained_features = models.vgg16_bn(
                weights=models.VGG16_BN_Weights.DEFAULT if pretrained else None
            ).features
        else: # torchvision.__version__ < 0.13
            models.vgg.model_urls['vgg16_bn'] = models.vgg.model_urls['vgg16_bn'].replace('https://', 'http://')
            vgg_pretrained_features = models.vgg16_bn(pretrained=pretrained).features
        
        self.slice1 = torch.nn.Sequential()
        self.slice2 = torch.nn.Sequential()
        self.slice3 = torch.nn.Sequential()
        self.slice4 = torch.nn.Sequential()
        self.slice5 = torch.nn.Sequential()
        for x in range(12):         # conv2_2
            self.slice1.add_module(str(x), vgg_pretrained_features[x])
        for x in range(12, 19):         # conv3_3
            self.slice2.add_module(str(x), vgg_pretrained_features[x])
        for x in range(19, 29):         # conv4_3
            self.slice3.add_module(str(x), vgg_pretrained_features[x])
        for x in range(29, 39):         # conv5_3
            self.slice4.add_module(str(x), vgg_pretrained_features[x])

        # fc6, fc7 without atrous conv
        self.slice5 = torch.nn.Sequential(
                nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
                nn.Conv2d(512, 1024, kernel_size=3, padding=6, dilation=6),
                nn.Conv2d(1024, 1024, kernel_size=1)
        )

        if not pretrained:
            init_weights(self.slice1.modules())
            init_weights(self.slice2.modules())
            init_weights(self.slice3.modules())
            init_weights(self.slice4.modules())

        init_weights(self.slice5.modules())        # no pretrained model for fc6 and fc7

        if freeze:
            for param in self.slice1.parameters():      # only first conv
                param.requires_grad= False

    def forward(self, X):
        h = self.slice1(X)
        h_relu2_2 = h
        h = self.slice2(h)
        h_relu3_2 = h
        h = self.slice3(h)
        h_relu4_3 = h
        h = self.slice4(h)
        h_relu5_3 = h
        h = self.slice5(h)
        h_fc7 = h
        return h_fc7, h_relu5_3, h_relu4_3, h_relu3_2, h_relu2_2




class double_conv(nn.Module):
    def __init__(self, in_ch, mid_ch, out_ch):
        super(double_conv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch + mid_ch, mid_ch, kernel_size=1),
            nn.BatchNorm2d(mid_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_ch, out_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.conv(x)
        return x


class CRAFT(nn.Module):
    def __init__(self, pretrained=True, freeze=False, amp=False):
        super(CRAFT, self).__init__()

        self.amp = amp

        """ Base network """
        self.basenet = vgg16_bn(pretrained, freeze)

        """ U network """
        self.upconv1 = double_conv(1024, 512, 256)
        self.upconv2 = double_conv(512, 256, 128)
        self.upconv3 = double_conv(256, 128, 64)
        self.upconv4 = double_conv(128, 64, 32)

        num_class = 2
        self.conv_cls = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, kernel_size=3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, kernel_size=1), nn.ReLU(inplace=True),
            nn.Conv2d(16, num_class, kernel_size=1),
        )

        init_weights(self.upconv1.modules())
        init_weights(self.upconv2.modules())
        init_weights(self.upconv3.modules())
        init_weights(self.upconv4.modules())
        init_weights(self.conv_cls.modules())
        
    def forward(self, x):
        """ Base network """
        if self.amp:
            with torch.cuda.amp.autocast():
                sources = self.basenet(x)

                """ U network """
                y = torch.cat([sources[0], sources[1]], dim=1)
                y = self.upconv1(y)

                y = F.interpolate(y, size=sources[2].size()[2:], mode='bilinear', align_corners=False)
                y = torch.cat([y, sources[2]], dim=1)
                y = self.upconv2(y)

                y = F.interpolate(y, size=sources[3].size()[2:], mode='bilinear', align_corners=False)
                y = torch.cat([y, sources[3]], dim=1)
                y = self.upconv3(y)

                y = F.interpolate(y, size=sources[4].size()[2:], mode='bilinear', align_corners=False)
                y = torch.cat([y, sources[4]], dim=1)
                feature = self.upconv4(y)

                y = self.conv_cls(feature)

                return y.permute(0,2,3,1), feature
        else:

            sources = self.basenet(x)

            """ U network """
            y = torch.cat([sources[0], sources[1]], dim=1)
            y = self.upconv1(y)

            y = F.interpolate(y, size=sources[2].size()[2:], mode='bilinear', align_corners=False)
            y = torch.cat([y, sources[2]], dim=1)
            y = self.upconv2(y)

            y = F.interpolate(y, size=sources[3].size()[2:], mode='bilinear', align_corners=False)
            y = torch.cat([y, sources[3]], dim=1)
            y = self.upconv3(y)

            y = F.interpolate(y, size=sources[4].size()[2:], mode='bilinear', align_corners=False)
            y = torch.cat([y, sources[4]], dim=1)
            feature = self.upconv4(y)

            y = self.conv_cls(feature)

            return y.permute(0, 2, 3, 1), feature




def copy_state_dict(state_dict):
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith("module") else k
        new_state_dict[name] = v
    return new_state_dict

def load_craft_model(model_path: str, use_cuda=True):
    net = CRAFT()
    print(f"Loading CRAFT model from: {model_path}")

    if not os.path.exists(model_path):
        raise FileNotFoundError(f"CRAFT model not found at {model_path}")

    state_dict = torch.load(model_path, map_location='cuda' if use_cuda else 'cpu')

    # Fix for checkpoint with full training dictionary
    if isinstance(state_dict, dict):
        if 'craft' in state_dict:
            print("Extracting CRAFT weights from checkpoint dictionary...")
            state_dict = state_dict['craft']
        elif 'state_dict' in state_dict:
            print("Extracting from 'state_dict'...")
            state_dict = state_dict['state_dict']

    net.load_state_dict(copy_state_dict(state_dict))
    net.eval()

    if use_cuda:
        net = net.cuda()

    return net

def run_craft_inference(net, image, text_threshold=0.7, link_threshold=0.4, low_text=0.4, canvas_size=1280, mag_ratio=1.5, use_cuda=True):
    img_resized, target_ratio, size_heatmap = resize_aspect_ratio(image, canvas_size, interpolation=cv2.INTER_LINEAR, mag_ratio=mag_ratio)
    ratio_h = ratio_w = 1 / target_ratio

    x = normalizeMeanVariance(img_resized)
    x = torch.from_numpy(x).permute(2, 0, 1).unsqueeze(0)

    if use_cuda:
        x = x.cuda()

    with torch.no_grad():
        y,_ = net(x)

    score_text = y[0, :, :, 0].cpu().data.numpy()
    score_link = y[0, :, :, 1].cpu().data.numpy()

    boxes, polys = getDetBoxes(score_text, score_link, text_threshold, link_threshold, low_text, poly=False)
    boxes = adjustResultCoordinates(boxes, ratio_w, ratio_h)
    polys = adjustResultCoordinates(polys, ratio_w, ratio_h)

    return boxes, polys
