import os
import cv2
import torch
import numpy as np
from ultralytics import YOLO
from utils.craft_utils import getDetBoxes, adjustResultCoordinates
from utils.imgproc import loadImage, resize_aspect_ratio, normalizeMeanVariance
import matplotlib.pyplot as plt

from collections import OrderedDict

# -------- Load Models Once --------
human_model = YOLO("models/human_detector_yolov8.pt")
bib_model = YOLO("models/number_detector_yolov8n.pt")

def load_craft_model():
    from utils.craft_utils import CRAFT
    net = CRAFT()
    state_dict = torch.load("models/text_detector_craft.pth", map_location="cpu")
    new_state = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith("module") else k
        new_state[name] = v
    net.load_state_dict(new_state)
    net.eval()
    return net

craft_net = load_craft_model()

# -------- Pipeline Logic --------
def crop_torso(image, bbox):
    x1, y1, x2, y2 = map(int, bbox)
    h = y2 - y1
    torso_top = y1 + h // 3
    torso_bottom = y1 + 2 * h // 3
    torso_top = max(0, torso_top)
    torso_bottom = min(image.shape[0], torso_bottom)
    return image[torso_top:torso_bottom, x1:x2]

def run_craft_on_crop(craft_model, crop):
    resized, ratio, _ = resize_aspect_ratio(crop, 1280, interpolation=cv2.INTER_LINEAR, mag_ratio=1.5)
    ratio_h, ratio_w = 1 / ratio, 1 / ratio
    normed = normalizeMeanVariance(resized)
    x = torch.from_numpy(normed).permute(2, 0, 1).unsqueeze(0).float()
    with torch.no_grad():
        y, _ = craft_model(x)
    score_text = y[0, :, :, 0].cpu().numpy()
    score_link = y[0, :, :, 1].cpu().numpy()
    boxes, _ = getDetBoxes(score_text, score_link, 0.7, 0.4, 0.4)
    boxes = adjustResultCoordinates(boxes, ratio_w, ratio_h)
    return boxes

def extract_bib_number(yolo_model, crop):
    digits = []
    results = yolo_model.predict(crop)
    for r in results:
        for box, cls in zip(r.boxes.xyxy.cpu().numpy(), r.boxes.cls.cpu().numpy()):
            if int(cls) in range(10):  # Only digit classes
                digits.append((int(box[0]), str(int(cls))))
    digits = sorted(digits, key=lambda d: d[0])
    return ''.join([d[1] for d in digits])

def visualize_bib_boxes(image, boxes):
    img = image.copy()
    for box in boxes:
        box = np.array(box).reshape(-1, 2)
        x1, y1 = box[:, 0].min(), box[:, 1].min()
        x2, y2 = box[:, 0].max(), box[:, 1].max()
        cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (255, 0, 0), 2)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.title("Bib Region Detected")
    plt.axis("off")
    plt.show()

def run_pipeline_on_image(image_path, visualize=False):
    image = loadImage(image_path)
    results = human_model.predict(image)
    persons = results[0].boxes.xyxy.cpu().numpy()

    for i, box in enumerate(persons):
        torso = crop_torso(image, box)
        if torso is None or torso.shape[0] < 10:
            continue

        craft_boxes = run_craft_on_crop(craft_net, torso)
        if not craft_boxes:
            continue

        if visualize:
            visualize_bib_boxes(torso, craft_boxes)

        bib_crop = torso  # Optional: crop to the text region here
        bib_number = extract_bib_number(bib_model, bib_crop)

        if bib_number:
            return torso, craft_boxes, bib_number

    return None, None, None
